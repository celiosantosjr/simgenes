This folder contains the images from the analysis of 1M random genes generated to test simgenes
